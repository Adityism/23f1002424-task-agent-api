#Unformatted Markdown

This  is a sample paragraph with extra  spaces and trailing whitespace.
-   First item
-    Second item
+Third item
    *    Fourth item

```py
print("23f1002424@ds.study.iitm.ac.in")

```
